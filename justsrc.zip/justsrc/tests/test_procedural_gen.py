import unittest
import sys
import os
import pygame

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from systems.graphics_engine import ProceduralGenerator

class TestProceduralGenerator(unittest.TestCase):
    def setUp(self):
        # Initialize pygame display if needed (often not needed for Surface creation but good practice)
        if not pygame.get_init():
            pygame.init()
            
    def test_generate_hex_background(self):
        # Test Common Weapon
        bg = ProceduralGenerator.generate_hex_background("weapon", "Common")
        self.assertIsInstance(bg, pygame.Surface)
        self.assertEqual(bg.get_width(), 64)
        self.assertEqual(bg.get_height(), 64)
        
        # Test Legendary Shield
        bg2 = ProceduralGenerator.generate_hex_background("shield", "Legendary")
        self.assertIsInstance(bg2, pygame.Surface)
        
    def test_tint_surface(self):
        surf = pygame.Surface((10, 10))
        surf.fill((255, 255, 255))
        tinted = ProceduralGenerator.tint_surface(surf, (255, 0, 0))
        
        # Check center pixel
        color = tinted.get_at((5, 5))
        # Should be red (255, 0, 0, 255)
        self.assertEqual(color, (255, 0, 0, 255))

if __name__ == '__main__':
    unittest.main()

import unittest
import sys
import os
import json

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from entities.enemy import Enemy
from entities.bot import Bot

class TestBoss(unittest.TestCase):
    def setUp(self):
        self.boss = Enemy("BossBot", 0, 0, ai_class="boss", level=10)
        self.player = Bot("Player", 100, 0)
        
        # Mock behavior data if file load fails or for consistency
        # In a real scenario, we might want to load the actual JSON to test it,
        # but for unit testing logic, we often mock. 
        # However, Enemy loads behaviors in __init__. 
        # Let's assume it loaded correctly or we can inject if needed.

    def test_boss_initial_state(self):
        self.assertEqual(self.boss.ai_class, "boss")
        self.assertGreater(self.boss.max_hp, 100) # Boss should be tough

    def test_phase_transition(self):
        # Simulate damage to trigger phase change
        # Assuming Boss has phases at certain HP thresholds (e.g. 50%)
        
        initial_hp = self.boss.max_hp
        self.boss.hp = initial_hp * 0.4 # Drop to 40%
        
        # Update to trigger logic
        self.boss.update(0.1, self.player, [], 0)
        
        # Check if behavior changed or special flag set
        # This depends on specific implementation, but let's assume 
        # the boss has a 'phase' attribute or changes state.
        # If not implemented yet, this test documents the expectation.
        # For now, we'll check if it enters a more aggressive state or uses a special move.
        
        # If the current implementation is simple, maybe it just changes state to 'attack'
        # Let's verify it has a target
        self.assertEqual(self.boss.target, self.player)

if __name__ == '__main__':
    unittest.main()

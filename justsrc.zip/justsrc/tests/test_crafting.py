import unittest
import sys
import os

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from systems.crafting_system import CraftingSystem
from equipment.component import ComponentEquipment

class TestCraftingSystem(unittest.TestCase):
    def setUp(self):
        self.crafting_system = CraftingSystem()
        self.comp1 = ComponentEquipment(name="Basic Arm", slot="left_arm", quality="Common", base_armor=10, base_hp=10, base_speed=10)
        self.comp2 = ComponentEquipment(name="Basic Arm", slot="left_arm", quality="Common", base_armor=10, base_hp=10, base_speed=10)
        self.comp3 = ComponentEquipment(name="Basic Leg", slot="left_leg", quality="Common")

    def test_fuse_same_slot(self):
        new_comp = self.crafting_system.fuse_components(self.comp1, self.comp2)
        self.assertIsNotNone(new_comp)
        self.assertEqual(new_comp.base_armor, 12)
        self.assertEqual(new_comp.quality, "Uncommon")

    def test_fuse_different_slot(self):
        new_comp = self.crafting_system.fuse_components(self.comp1, self.comp3)
        self.assertIsNone(new_comp)

    def test_fuse_different_quality(self):
        self.comp2.quality = "Uncommon"
        new_comp = self.crafting_system.fuse_components(self.comp1, self.comp2)
        self.assertIsNotNone(new_comp)
        self.assertEqual(new_comp.quality, "Common") # Should keep lowest or first? Logic says comp1.quality if not equal

if __name__ == '__main__':
    unittest.main()

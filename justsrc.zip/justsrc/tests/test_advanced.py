import unittest
import sys
import os
import math

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from equipment.component import ComponentEquipment, create_random_component
from systems.crafting_system import CraftingSystem
from entities.enemy import Enemy
from entities.bot import Bot

class TestAdvancedFeatures(unittest.TestCase):
    def test_crafting_grid_expansion(self):
        """Test that merging expands the grid (via quality upgrade)."""
        crafting = CraftingSystem()
        
        # Create two Common components
        c1 = ComponentEquipment(name="Test Comp 1", slot="head", quality="Common")
        c2 = ComponentEquipment(name="Test Comp 2", slot="head", quality="Common")
        
        # Fuse them
        fused = crafting.fuse_components(c1, c2)
        
        self.assertEqual(fused.quality, "Uncommon")
        self.assertEqual(fused.grid_height, 4) # Uncommon is 3x4
        self.assertEqual(fused.merge_count, 1)
        self.assertTrue(fused.name.endswith("+1"))

    def test_logarithmic_speed(self):
        """Test that speed scaling is logarithmic."""
        bot = Bot("Test Bot", 0, 0)
        
        # Base speed
        bot.recalculate_stats()
        base_speed = bot.max_speed
        self.assertEqual(base_speed, 150.0)
        
        # Add speed bonus
        # Create a component with speed
        leg = ComponentEquipment(name="Fast Leg", slot="left_leg", quality="Common", base_speed=10.0)
        bot.equip_component(leg)
        
        # Expected: 150 + 50 * log(10 + 1) = 150 + 50 * 2.397 = 269.8
        expected = 150.0 + (math.log(11) * 50.0)
        self.assertAlmostEqual(bot.max_speed, expected, places=1)
        
        # Add MASSIVE speed bonus
        leg2 = ComponentEquipment(name="Super Leg", slot="right_leg", quality="Legendary", base_speed=100.0)
        bot.equip_component(leg2)
        
        # Total bonus 110
        # Expected: 150 + 50 * log(111) = 150 + 50 * 4.7 = 385
        expected_massive = 150.0 + (math.log(111) * 50.0)
        self.assertAlmostEqual(bot.max_speed, expected_massive, places=1)
        
        # Ensure it's not linear (Linear would be 150 + 110*20 = 2350)
        self.assertLess(bot.max_speed, 1000)

    def test_ai_behavior(self):
        """Test basic AI state transitions."""
        # Sniper
        sniper = Enemy("Sniper", 0, 0, ai_class="sniper")
        player = Bot("Player", 100, 0) # 100 units away
        
        # Sniper attack range is 500. 100 is too close (0.2 * range). Should flee.
        # First update: Idle -> Chase
        sniper.update(0.1, player, None, 0)
        # Second update: Chase -> Flee
        sniper.update(0.1, player, None, 0)
        self.assertEqual(sniper.state, "flee")
        
        # Grunt
        grunt = Enemy("Grunt", 0, 0, ai_class="grunt")
        player.x = 300 # 300 units away. Detection 400. Attack 200. Should chase.
        # First update: Idle -> Chase
        grunt.update(0.1, player, None, 0)
        self.assertEqual(grunt.state, "chase")

if __name__ == '__main__':
    unittest.main()

import unittest
import sys
import os

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from systems.synergy_manager import SynergyManager
from hex_system.energy_packet import EnergyPacket, SynergyType

class TestSynergyManager(unittest.TestCase):
    def setUp(self):
        # Reset singleton for testing
        SynergyManager._instance = None
        self.manager = SynergyManager()

    def test_load_data(self):
        """Test that data is loaded correctly from JSON."""
        self.assertIn("fire", self.manager.base_synergies)
        self.assertIn("ice", self.manager.base_synergies)
        self.assertTrue(len(self.manager.combinations) > 0)

    def test_calculate_synergy_base(self):
        """Test simple base synergy calculation."""
        packet = EnergyPacket(magnitude=100.0)
        packet.synergies = {SynergyType.FIRE: 100.0}
        
        result = self.manager.calculate_synergy(packet)
        self.assertEqual(result.name, "fire")
        self.assertFalse(result.is_combination)

    def test_calculate_synergy_combination(self):
        """Test combination logic (Fire + Ice = Steam)."""
        packet = EnergyPacket(magnitude=100.0)
        packet.synergies = {
            SynergyType.FIRE: 50.0,
            SynergyType.ICE: 50.0
        }
        
        result = self.manager.calculate_synergy(packet)
        self.assertEqual(result.name, "steam")
        self.assertTrue(result.is_combination)
        self.assertIn("damage_multiplier", result.effects)

    def test_calculate_synergy_partial(self):
        """Test that minor synergies are ignored."""
        packet = EnergyPacket(magnitude=100.0)
        packet.synergies = {
            SynergyType.FIRE: 95.0,
            SynergyType.ICE: 5.0 # Below 10% threshold
        }
        
        result = self.manager.calculate_synergy(packet)
        self.assertEqual(result.name, "fire") # Should be fire, not steam

    def test_get_synergy_effects(self):
        """Test retrieving effects by name."""
        effects = self.manager.get_synergy_effects("steam")
        self.assertIn("damage_multiplier", effects)
        
        effects = self.manager.get_synergy_effects("nonexistent")
        self.assertEqual(effects, {})

if __name__ == '__main__':
    unittest.main()

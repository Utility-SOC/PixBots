import sys
import os
import time
import logging

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import pygame
from systems.music import music_system

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_stress():
    logger.info("Starting Music Stress Test...")
    
    pygame.init()
    music_system.init()
    music_system.start_music()
    
    biomes = ["beach", "mountain", "tundra", "volcano"]
    
    try:
        for i in range(10):
            biome = biomes[i % len(biomes)]
            logger.info(f"Switching to {biome}...")
            music_system.set_biome(biome)
            
            # Run for a bit
            time.sleep(2.0)
            
            # Simulate frame updates (if any logic needed it, but sequencer is threaded)
            
    except KeyboardInterrupt:
        pass
    except Exception as e:
        logger.error(f"Stress test failed: {e}", exc_info=True)
    finally:
        logger.info("Shutting down...")
        music_system.shutdown()
        pygame.quit()

if __name__ == "__main__":
    test_stress()

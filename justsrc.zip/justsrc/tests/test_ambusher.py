import unittest
import sys
import os

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from entities.enemy import Enemy
from entities.bot import Bot

class TestAmbusher(unittest.TestCase):
    def setUp(self):
        self.ambusher = Enemy("SneakyBot", 0, 0, ai_class="ambusher")
        self.player = Bot("Player", 500, 0) # Far away

    def test_ambusher_behavior(self):
        # Current implementation uses simple chase logic for Ambusher
        self.ambusher.update(0.1, self.player, None, 0)
        
        dist = ((self.ambusher.x - self.player.x)**2 + (self.ambusher.y - self.player.y)**2)**0.5
        
        # Should be moving towards player (chase)
        initial_dist = dist
        self.ambusher.update(1.0, self.player, None, 0)
        new_dist = ((self.ambusher.x - self.player.x)**2 + (self.ambusher.y - self.player.y)**2)**0.5
        
        self.assertLess(new_dist, initial_dist)
        self.assertEqual(self.ambusher.state, "chase")

    def test_ambusher_attack(self):
        # When close, should attack
        self.ambusher.x = 450 # Player at 500, dist 50.
        self.ambusher.update(0.1, self.player, None, 0)
        
        self.assertEqual(self.ambusher.state, "attack")

if __name__ == '__main__':
    unittest.main()

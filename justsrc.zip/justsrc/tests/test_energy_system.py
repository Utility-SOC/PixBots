import unittest
from equipment.component import ComponentEquipment, create_starter_arm
from hex_system.hex_coord import HexCoord
from hex_system.hex_tile import AmplifierTile, ResonatorTile, TileCategory, WeaponMountTile

class TestEnergySystem(unittest.TestCase):
    def test_amplifier_effect(self):
        # Create a right arm (Entry at 0,1 -> Exit at 2,1 for 3x3 grid?)
        # Let's check grid size. default is usually 4x4 or similar.
        # create_starter_arm uses default grid.
        
        arm = create_starter_arm("right_arm")
        # Starter arm has a weapon mount at (1,1).
        # Right arm entry is (0, mid_r), exit is (width-1, mid_r).
        # Let's assume grid is 3x3 for simplicity or check default.
        # ComponentEquipment default is 4x4. mid_r = 2.
        # Entry: (0, 2), Exit: (3, 2).
        
        # Let's manually set up a simple path.
        # We need to place tiles to connect (0,2) to (3,2).
        
        # Clear existing tiles
        arm.tile_slots = {}
        
        # Place tiles for a straight line
        # (0,2) -> (1,2) -> (2,2) -> (3,2)
        
        # Place Amplifier at (1,2)
        amp = AmplifierTile("Amp", TileCategory.PROCESSOR)
        amp.amplification = 1.5
        arm.place_tile(HexCoord(1, 2), amp)
        
        # Place Weapon Mount at (3,2) (Exit)
        mount = WeaponMountTile("Mount", TileCategory.OUTPUT, weapon_type="beam")
        arm.place_tile(HexCoord(3, 2), mount)
        
        # We need conduits to connect them if they are not adjacent?
        # (0,2) is entry. (1,2) is neighbor.
        # (1,2) -> (2,2) -> (3,2)
        # We need a tile at (2,2) to bridge the gap?
        # Or we can just put the mount at (2,2) if it's adjacent.
        
        # Let's try a shorter path.
        # Entry (0,2). Neighbor (1,2). Neighbor (2,2).
        
        # Let's just test that the simulation runs and picks up the amplifier.
        # The simulation traces from Entry.
        # If we put an amplifier at (0,2) (Entry), it should be picked up.
        
        amp_entry = AmplifierTile("AmpEntry", TileCategory.PROCESSOR)
        amp_entry.amplification = 2.0
        arm.place_tile(HexCoord(0, 2), amp_entry)
        
        # And a mount at (1,2)
        mount = WeaponMountTile("Mount", TileCategory.OUTPUT, weapon_type="beam")
        arm.place_tile(HexCoord(1, 2), mount)
        
        # Calculate stats
        stats = arm.calculate_stats()
        
        # Base multiplier is 1.0. Amp is 2.0.
        # Should be 2.0.
        self.assertAlmostEqual(stats["damage_multiplier"], 2.0)
        
        # Weapon damage should be influenced
        # Base packet is 100.0.
        # Weapon damage = packet * multiplier * 0.5 = 100 * 2.0 * 0.5 = 100.0
        self.assertAlmostEqual(stats["weapon_damage"], 100.0)

    def test_broken_connection(self):
        arm = create_starter_arm("right_arm")
        arm.tile_slots = {}
        
        # Place Amplifier at (1,2) but NO tile at (0,2) (Entry)
        # So energy cannot reach the amplifier.
        amp = AmplifierTile("Amp", TileCategory.PROCESSOR)
        amp.amplification = 2.0
        arm.place_tile(HexCoord(1, 2), amp)
        
        stats = arm.calculate_stats()
        
        # Should be 1.0 (default) because flow didn't reach amp
        self.assertEqual(stats["damage_multiplier"], 1.0)

if __name__ == '__main__':
    unittest.main()

import unittest
import sys
import os

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from entities.enemy import Enemy

class TestEnemy(unittest.TestCase):
    def test_level_scaling(self):
        e1 = Enemy("E1", 0, 0, level=1)
        e5 = Enemy("E5", 0, 0, level=5)
        
        self.assertGreater(e5.max_hp, e1.max_hp)
        self.assertGreater(e5.weapon["damage"], e1.weapon["damage"])
        
    def test_tactics_assignment(self):
        e1 = Enemy("E1", 0, 0, level=1)
        self.assertIn("attack", e1.tactics)
        self.assertNotIn("shield", e1.tactics)
        
        e5 = Enemy("E5", 0, 0, level=5)
        self.assertIn("shield", e5.tactics)
        self.assertIn("buff", e5.tactics)

    def test_shield_damage_reduction(self):
        e = Enemy("E", 0, 0, level=5)
        e.shield_active = True
        
        initial_hp = e.hp
        damage = 20
        e.take_damage(damage)
        
        # Should take 10 damage (50% of 20)
        # Note: Bot.take_damage subtracts armor. Default armor is 0.
        expected_hp = initial_hp - 10
        self.assertEqual(e.hp, expected_hp)

if __name__ == '__main__':
    unittest.main()

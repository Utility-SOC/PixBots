import unittest
import sys
import os
import math

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from systems.combat_system import CombatSystem
from entities.player import Player
from entities.enemy import Enemy
from core.asset_manager import ProceduralAssetManager
import constants

class MockGameMap:
    def __init__(self):
        self.width = 100
        self.height = 100
        self.terrain = [[constants.GRASS for _ in range(100)] for _ in range(100)]
        self.obstacles = set()

class TestCombatSystem(unittest.TestCase):
    def setUp(self):
        self.asset_manager = ProceduralAssetManager()
        self.combat_system = CombatSystem(self.asset_manager)
        self.game_map = MockGameMap()
        
    def test_deal_damage(self):
        player = Player("Player", 10, 10)
        initial_hp = player.hp
        damage = 10
        
        self.combat_system.deal_damage(player, damage)
        
        # Player has armor, so damage might be reduced.
        # Default starter armor is usually 0 unless equipped.
        # Let's assume 0 armor for bare player.
        # Wait, Player.__init__ calls recalculate_stats which might set armor if components are default?
        # Player starts with empty components dict.
        
        expected_hp = initial_hp - damage
        self.assertEqual(player.hp, expected_hp)
        
    def test_projectile_collision(self):
        player = Player("Player", 50, 50)
        enemy = Enemy("Enemy", 10, 10)
        
        # Spawn projectile from enemy aiming at player
        self.combat_system.spawn_projectile(
            x=50, y=50, # Spawn ON the player
            angle=0, speed=0, 
            damage=10, damage_type="physical", owner="enemy"
        )
        
        # Update combat system
        dt = 0.1
        all_bots = [player, enemy]
        self.combat_system.update(dt, self.game_map, all_bots)
        
        # Player should have taken damage
        self.assertLess(player.hp, player.max_hp)
        
        # Projectile should be inactive
        self.assertFalse(self.combat_system.projectiles[0].active)

if __name__ == '__main__':
    unittest.main()

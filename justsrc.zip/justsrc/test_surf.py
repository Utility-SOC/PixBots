import pygame
import time
import logging
from systems.music import Instrument, Note, SAMPLE_RATE

logging.basicConfig(level=logging.DEBUG)

def test_surf():
    pygame.mixer.pre_init(44100, -16, 2, 2048)
    pygame.init()
    pygame.mixer.init()
    
    print("Initializing Surf Guitar...")
    surf = Instrument(
        "Surf Guitar",
        waveform="karplus_strong",
        volume=0.8,
        effects=[
            {"type": "distortion", "drive": 2.0},
            {"type": "tremolo", "rate": 6.0, "depth": 0.8},
            {"type": "delay", "time": 0.15, "feedback": 0.3}
        ]
    )
    
    print("Generating Note (Pitch 60, 2.0s)...")
    note = Note(60, 2.0, surf)
    
    print("Playing Note...")
    note.sound.play()
    
    time.sleep(3.0)
    print("Done.")

if __name__ == "__main__":
    test_surf()
